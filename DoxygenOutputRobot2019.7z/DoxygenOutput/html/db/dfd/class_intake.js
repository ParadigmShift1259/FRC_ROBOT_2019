var class_intake =
[
    [ "CargoStage", "db/dfd/class_intake.html#a41f57cc21d4309bd3873660762f56c65", [
      [ "kCargoIdle", "db/dfd/class_intake.html#a41f57cc21d4309bd3873660762f56c65ae1da1d842663ac33fb0ce584e61f47ea", null ],
      [ "kCargoIngest", "db/dfd/class_intake.html#a41f57cc21d4309bd3873660762f56c65aa53b9db352b8e71b53c75532cf18b7bb", null ],
      [ "kCargoIngestWait", "db/dfd/class_intake.html#a41f57cc21d4309bd3873660762f56c65a63afd5865b75384bb1f8877285bcf91c", null ],
      [ "kCargoBall", "db/dfd/class_intake.html#a41f57cc21d4309bd3873660762f56c65a1b1f26f193787b00c58f7f2802697fd8", null ],
      [ "kCargoEject", "db/dfd/class_intake.html#a41f57cc21d4309bd3873660762f56c65a705998bd973319c5e74bb288cae30e39", null ]
    ] ],
    [ "HatchStage", "db/dfd/class_intake.html#aa9ea90d803f7510891c50cd807eae1bf", [
      [ "kHatchIdle", "db/dfd/class_intake.html#aa9ea90d803f7510891c50cd807eae1bfaab8c5d142c78584f1f08a8851c277a8d", null ],
      [ "kHatchCapture", "db/dfd/class_intake.html#aa9ea90d803f7510891c50cd807eae1bfa744271dfe4215845d275e98bca37e123", null ],
      [ "kHatchRelease", "db/dfd/class_intake.html#aa9ea90d803f7510891c50cd807eae1bfa628a21a6b0a8979c8996fc51b83aa21f", null ]
    ] ],
    [ "IntakeMode", "db/dfd/class_intake.html#acd623c31574ed6ca76044cb91128a82c", [
      [ "kModeHatch", "db/dfd/class_intake.html#acd623c31574ed6ca76044cb91128a82ca7d6f2e63d597ca7d5bea2f1d92c86d3c", null ],
      [ "kModeCargo", "db/dfd/class_intake.html#acd623c31574ed6ca76044cb91128a82ca43211934e445ca19465762e3fa8500cf", null ],
      [ "kModeAny", "db/dfd/class_intake.html#acd623c31574ed6ca76044cb91128a82ca078bb50f18e4473df13939fec0271779", null ]
    ] ],
    [ "Intake", "db/dfd/class_intake.html#a66b32fbeaae2fdbf79212af7cda8f87a", null ],
    [ "~Intake", "db/dfd/class_intake.html#a0bd65acd1cb4ad03c9fc0286f3b57b9b", null ],
    [ "CargoLoop", "db/dfd/class_intake.html#ad83f61b319aad21d62143fa924f74925", null ],
    [ "HatchLoop", "db/dfd/class_intake.html#aa498f66427f70e8c366bf56cfde7ed2e", null ],
    [ "Init", "db/dfd/class_intake.html#a4183327f421b934ffa706523996a0c68", null ],
    [ "Stop", "db/dfd/class_intake.html#a1250a271575e444201b1ac70be018031", null ],
    [ "TestLoop", "db/dfd/class_intake.html#a377fde385075ee16908e57aad7644897", null ],
    [ "m_cargosensor", "db/dfd/class_intake.html#a1ad62ccecce315be3cfdd9afb6634a3a", null ],
    [ "m_cargostage", "db/dfd/class_intake.html#a42dddf03797f00775111a90a346eedef", null ],
    [ "m_ds", "db/dfd/class_intake.html#a5c54dac22d9e27f436520f43519e0474", null ],
    [ "m_hatchstage", "db/dfd/class_intake.html#af5d70bfaed244340adfd419b8f62cfb7", null ],
    [ "m_inputs", "db/dfd/class_intake.html#a2fc105e9af000b8f84e1e1dede73059b", null ],
    [ "m_lifter", "db/dfd/class_intake.html#a466d0bb026341b52521f51bb3e430b44", null ],
    [ "m_mode", "db/dfd/class_intake.html#a5c22d407ca84d12f05d08a239b90629a", null ],
    [ "m_motor", "db/dfd/class_intake.html#a726755b74b33e9637848175320f0265d", null ],
    [ "m_onfloor", "db/dfd/class_intake.html#ae4457982bf1fc39b061d60832fef5608", null ],
    [ "m_solenoidarm1", "db/dfd/class_intake.html#addbef8af2bab7c876d258b7f4a1f2875", null ],
    [ "m_solenoidarm2", "db/dfd/class_intake.html#acb8a5d3fb6da42e338a16993f2e89543", null ],
    [ "m_solenoidhatch1", "db/dfd/class_intake.html#acfc52de1e0b8aca11eafdbead4eb3f22", null ],
    [ "m_solenoidhatch2", "db/dfd/class_intake.html#a14f930b725406e24becd5557feb2c06c", null ],
    [ "m_solenoidvac1", "db/dfd/class_intake.html#a9b08f30d92928fe86373c2c1718e8cc7", null ],
    [ "m_solenoidvac2", "db/dfd/class_intake.html#adc9dc0c155fb642619e7a199eacc16b2", null ],
    [ "m_spark1", "db/dfd/class_intake.html#af94cd62b5b623ca507fd1ee538c3f21d", null ],
    [ "m_spark2", "db/dfd/class_intake.html#a5f8c6ce0c8f740809070819c81b0c719", null ],
    [ "m_timer", "db/dfd/class_intake.html#a66eef65c1f976c35bbbb3d6338879b3a", null ],
    [ "m_waittime", "db/dfd/class_intake.html#abb1c6b8f7de56e0448d6f77ae8160d99", null ]
];
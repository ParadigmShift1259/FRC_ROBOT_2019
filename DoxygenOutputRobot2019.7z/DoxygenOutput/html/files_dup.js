var files_dup =
[
    [ "Autonomous.cpp", "d4/d45/_autonomous_8cpp.html", null ],
    [ "Autonomous.h", "d2/d12/_autonomous_8h.html", [
      [ "Autonomous", "de/d9b/class_autonomous.html", "de/d9b/class_autonomous" ]
    ] ],
    [ "Const.h", "dd/d59/_const_8h.html", "dd/d59/_const_8h" ],
    [ "DrivePID.cpp", "d9/db4/_drive_p_i_d_8cpp.html", null ],
    [ "DrivePID.h", "d2/da1/_drive_p_i_d_8h.html", [
      [ "DrivePID", "d1/d75/class_drive_p_i_d.html", "d1/d75/class_drive_p_i_d" ]
    ] ],
    [ "Drivetrain.cpp", "da/d8d/_drivetrain_8cpp.html", null ],
    [ "Drivetrain.h", "db/d8e/_drivetrain_8h.html", [
      [ "DriveTrain", "d9/db0/class_drive_train.html", "d9/db0/class_drive_train" ]
    ] ],
    [ "Gyro.cpp", "d4/d47/_gyro_8cpp.html", null ],
    [ "Gyro.h", "de/d42/_gyro_8h.html", [
      [ "DualGyro", "d4/d13/class_dual_gyro.html", "d4/d13/class_dual_gyro" ]
    ] ],
    [ "GyroDrive.cpp", "d9/ddc/_gyro_drive_8cpp.html", null ],
    [ "GyroDrive.h", "da/d0f/_gyro_drive_8h.html", [
      [ "GyroDrive", "d8/dfb/class_gyro_drive.html", "d8/dfb/class_gyro_drive" ]
    ] ],
    [ "Intake.cpp", "dd/d11/_intake_8cpp.html", null ],
    [ "Intake.h", "d2/de7/_intake_8h.html", [
      [ "Intake", "db/dfd/class_intake.html", "db/dfd/class_intake" ]
    ] ],
    [ "Lifter.cpp", "d2/d51/_lifter_8cpp.html", null ],
    [ "Lifter.h", "d2/d15/_lifter_8h.html", [
      [ "Lifter", "dd/d56/class_lifter.html", "dd/d56/class_lifter" ]
    ] ],
    [ "main.cpp", "df/d0a/main_8cpp.html", "df/d0a/main_8cpp" ],
    [ "OperatorInputs.cpp", "d5/d08/_operator_inputs_8cpp.html", null ],
    [ "OperatorInputs.h", "db/d71/_operator_inputs_8h.html", [
      [ "OperatorInputs", "d5/dbf/class_operator_inputs.html", "d5/dbf/class_operator_inputs" ]
    ] ],
    [ "Robot.cpp", "d1/d81/_robot_8cpp.html", "d1/d81/_robot_8cpp" ],
    [ "Robot.h", "df/d42/_robot_8h.html", [
      [ "Robot", "d4/d84/class_robot.html", "d4/d84/class_robot" ]
    ] ]
];
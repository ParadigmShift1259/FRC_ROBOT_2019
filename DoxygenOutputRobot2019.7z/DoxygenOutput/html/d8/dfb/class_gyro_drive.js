var class_gyro_drive =
[
    [ "DriveState", "d8/dfb/class_gyro_drive.html#af1b04d8f1a2c6a99d14e13678290c53d", [
      [ "kInit", "d8/dfb/class_gyro_drive.html#af1b04d8f1a2c6a99d14e13678290c53da7d8ce6656afd3338da202f4c81c6ddcc", null ],
      [ "kDrive", "d8/dfb/class_gyro_drive.html#af1b04d8f1a2c6a99d14e13678290c53daed1f75cf2f6107f0e36894699cc2c6cf", null ]
    ] ],
    [ "GyroDrive", "d8/dfb/class_gyro_drive.html#a73ee60d1f4ef70a0898e02f85c8e378d", null ],
    [ "~GyroDrive", "d8/dfb/class_gyro_drive.html#a9902a39dc47238ec6ffe854f47351459", null ],
    [ "Disabled", "d8/dfb/class_gyro_drive.html#aa5ecf141d1615f4fd1502524ce38af38", null ],
    [ "Drive", "d8/dfb/class_gyro_drive.html#a4155ddc2e1a556c0a11488ea9da77031", null ],
    [ "DriveAngle", "d8/dfb/class_gyro_drive.html#a08ffbf450a6ca1cd78b28e310312086a", null ],
    [ "DriveHeading", "d8/dfb/class_gyro_drive.html#ac55ece4ebeeafb5c6e4f4d88681de508", null ],
    [ "DriveStraight", "d8/dfb/class_gyro_drive.html#ad9754bf9ea8130ccce1d8a59ffe628a8", null ],
    [ "Init", "d8/dfb/class_gyro_drive.html#ad86e78a58a6c758940b272f2e7699f17", null ],
    [ "Loop", "d8/dfb/class_gyro_drive.html#a53da862c56fb4089013d756d1fd84042", null ],
    [ "SetAnglePID", "d8/dfb/class_gyro_drive.html#a32518a2443fc077aabc5b977fd26aa7f", null ],
    [ "SetStraightPID", "d8/dfb/class_gyro_drive.html#a5e0ad658d6d0298b8a06aba03b2fe3f0", null ],
    [ "Stop", "d8/dfb/class_gyro_drive.html#aa2abdf2c754bda5100cbb76038a98ddd", null ],
    [ "m_distance", "d8/dfb/class_gyro_drive.html#aebda487b1dab4575a820e22a4f8e0e63", null ],
    [ "m_drivepid", "d8/dfb/class_gyro_drive.html#aa6b3515898cc664d6c34d76942bc3013", null ],
    [ "m_drivestate", "d8/dfb/class_gyro_drive.html#aedb14b182636fa7b5aa6347ba231da26", null ],
    [ "m_drivetrain", "d8/dfb/class_gyro_drive.html#a634064a33b5b0ef306c1b39a0692d657", null ],
    [ "m_gyro", "d8/dfb/class_gyro_drive.html#a4bd05c3b0c811cc2158106fd348963f8", null ],
    [ "m_inputs", "d8/dfb/class_gyro_drive.html#ac98bbccadded6e8d0ac63c61e53c8529", null ],
    [ "m_pidangle", "d8/dfb/class_gyro_drive.html#ae43eea0a017ab35230ee3bf4f43b83b7", null ],
    [ "m_pidstraight", "d8/dfb/class_gyro_drive.html#a2b0501f36a5f525ca6d6ca757d01f180", null ],
    [ "m_timer", "d8/dfb/class_gyro_drive.html#a610b7c95e5e24280800c9620d58cee28", null ]
];
var annotated_dup =
[
    [ "Autonomous", "de/d9b/class_autonomous.html", "de/d9b/class_autonomous" ],
    [ "DrivePID", "d1/d75/class_drive_p_i_d.html", "d1/d75/class_drive_p_i_d" ],
    [ "DriveTrain", "d9/db0/class_drive_train.html", "d9/db0/class_drive_train" ],
    [ "DualGyro", "d4/d13/class_dual_gyro.html", "d4/d13/class_dual_gyro" ],
    [ "GyroDrive", "d8/dfb/class_gyro_drive.html", "d8/dfb/class_gyro_drive" ],
    [ "Intake", "db/dfd/class_intake.html", "db/dfd/class_intake" ],
    [ "Lifter", "dd/d56/class_lifter.html", "dd/d56/class_lifter" ],
    [ "OperatorInputs", "d5/dbf/class_operator_inputs.html", "d5/dbf/class_operator_inputs" ],
    [ "Robot", "d4/d84/class_robot.html", "d4/d84/class_robot" ]
];
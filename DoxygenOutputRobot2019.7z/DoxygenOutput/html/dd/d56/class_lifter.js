var class_lifter =
[
    [ "Stage", "dd/d56/class_lifter.html#a8a38e890cd82e77e31cb0341ccb9fa31", [
      [ "kIdle", "dd/d56/class_lifter.html#a8a38e890cd82e77e31cb0341ccb9fa31a357c7e47a3df49057ca8e38835098a28", null ],
      [ "kRaise", "dd/d56/class_lifter.html#a8a38e890cd82e77e31cb0341ccb9fa31a0eacbad61bdfdcd7bf19b70c673ccd85", null ]
    ] ],
    [ "Lifter", "dd/d56/class_lifter.html#aa0debbd89090eed2bae1870b0465e761", null ],
    [ "~Lifter", "dd/d56/class_lifter.html#aa033283051cacbca436b1844578e317e", null ],
    [ "AutoRaise", "dd/d56/class_lifter.html#a2de659090d26f258a650b7b960cb6daa", null ],
    [ "AutoRaiseSwitch", "dd/d56/class_lifter.html#a39e9ef3a5b9230589f2bdf81a57f97fb", null ],
    [ "Init", "dd/d56/class_lifter.html#aea017150f1ad78408bd4000cc75d0c49", null ],
    [ "IsBottom", "dd/d56/class_lifter.html#aee31706d2889675d6be800600f532958", null ],
    [ "Loop", "dd/d56/class_lifter.html#af70412b6b2fa656fc7ed34bd001c0631", null ],
    [ "MoveBottom", "dd/d56/class_lifter.html#a775a8132cf253e7fb8728d2d2be1c940", null ],
    [ "MoveSmidgeUp", "dd/d56/class_lifter.html#a2df4059797f4be429fc9f26e0b3062a7", null ],
    [ "ResetPosition", "dd/d56/class_lifter.html#a00f19566e8efd05db0179930bb9ff046", null ],
    [ "Stop", "dd/d56/class_lifter.html#a8fd44e1b317355f4c53b05162d183844", null ],
    [ "TestLoop", "dd/d56/class_lifter.html#aeb636f030679e31a47630cafa2d3b68b", null ],
    [ "m_ds", "dd/d56/class_lifter.html#ae6c69d2f7fa835a6a4d06838d16428c4", null ],
    [ "m_inputs", "dd/d56/class_lifter.html#ac0e0c441e049365ffd6e2c1f40ab262d", null ],
    [ "m_liftermax", "dd/d56/class_lifter.html#a24f5a8c43027ff8eb91ee062d9e947bb", null ],
    [ "m_liftermaxspd", "dd/d56/class_lifter.html#af8161f838bb9f5054987eff1e0164bd9", null ],
    [ "m_liftermin", "dd/d56/class_lifter.html#a986ca97d743c26f3e8f99781a90a60a3", null ],
    [ "m_lifterminspd", "dd/d56/class_lifter.html#a49b64d38605eae6d21b6f102a4feeaad", null ],
    [ "m_lowerspeed", "dd/d56/class_lifter.html#a472f312a59e1bf013fe4a491b7f61685", null ],
    [ "m_motor", "dd/d56/class_lifter.html#ab64d8418fbc761480d961a9b50639128", null ],
    [ "m_position", "dd/d56/class_lifter.html#af9f1860b6237c16adcb5f9fc72f6dd73", null ],
    [ "m_raisespeed", "dd/d56/class_lifter.html#a64edbc48786320403c001cdf2bd8e986", null ],
    [ "m_stage", "dd/d56/class_lifter.html#a38f8cbc72d445e601c36688efe867b1c", null ]
];
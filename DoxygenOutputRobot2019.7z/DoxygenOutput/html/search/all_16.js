var searchData=
[
  ['zeroheading',['ZeroHeading',['../d4/d13/class_dual_gyro.html#af60b637668fe6dc9cfbfa413d6b20ffb',1,'DualGyro']]]
];

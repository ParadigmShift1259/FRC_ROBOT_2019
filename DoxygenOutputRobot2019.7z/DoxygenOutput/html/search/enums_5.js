var searchData=
[
  ['stage',['Stage',['../dd/d56/class_lifter.html#a8a38e890cd82e77e31cb0341ccb9fa31',1,'Lifter']]]
];

var searchData=
[
  ['getaveragemaxdistance',['GetAverageMaxDistance',['../d9/db0/class_drive_train.html#ab4a3261551149e162a9d227e5390614d',1,'DriveTrain']]],
  ['getenabled',['GetEnabled',['../d1/d75/class_drive_p_i_d.html#ae4ce9c64b2d13fe34d6136a5655e79cb',1,'DrivePID']]],
  ['getheading',['GetHeading',['../d4/d13/class_dual_gyro.html#a79fb4ec5e97be5c5499070f88cfb7147',1,'DualGyro']]],
  ['getishighgear',['getIsHighGear',['../d9/db0/class_drive_train.html#aab3abc53ae85736f0b23ca9daf660a18',1,'DriveTrain']]],
  ['getleftdistance',['GetLeftDistance',['../d9/db0/class_drive_train.html#a8e277b06dd21aa9f6ef3b8e0afa54890',1,'DriveTrain']]],
  ['getleftposition',['GetLeftPosition',['../d9/db0/class_drive_train.html#ac3f06f2a6637753b69ab690177e582d2',1,'DriveTrain']]],
  ['getleftvelocity',['GetLeftVelocity',['../d9/db0/class_drive_train.html#af1b993f121d1e8899f2d27dfbf287c49',1,'DriveTrain']]],
  ['getmaxdeltadistance',['GetMaxDeltaDistance',['../d9/db0/class_drive_train.html#a07e88724c09ad85237e099da8c68b39e',1,'DriveTrain']]],
  ['getmaxdistance',['GetMaxDistance',['../d9/db0/class_drive_train.html#a68fc24930c59b4cd0143b17cf91264a4',1,'DriveTrain']]],
  ['getmaxvelocity',['GetMaxVelocity',['../d9/db0/class_drive_train.html#a44c8abad968d5320afb6bbe89c1b4df9',1,'DriveTrain']]],
  ['getrightdistance',['GetRightDistance',['../d9/db0/class_drive_train.html#aafbbc011623fbc34dc89d464e6b9d6ef',1,'DriveTrain']]],
  ['getrightposition',['GetRightPosition',['../d9/db0/class_drive_train.html#a36ac45fc7b052c49f9723db37f82811d',1,'DriveTrain']]],
  ['getrightvelocity',['GetRightVelocity',['../d9/db0/class_drive_train.html#aca1ef6a6d73cbf7054859b321ae889e4',1,'DriveTrain']]],
  ['gyrodrive',['GyroDrive',['../d8/dfb/class_gyro_drive.html#a73ee60d1f4ef70a0898e02f85c8e378d',1,'GyroDrive']]]
];

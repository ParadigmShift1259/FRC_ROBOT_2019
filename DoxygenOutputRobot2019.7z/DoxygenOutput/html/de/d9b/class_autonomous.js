var class_autonomous =
[
    [ "Autonomous", "de/d9b/class_autonomous.html#a55bfe172a746dfa8d6f0e247a10249ed", null ],
    [ "~Autonomous", "de/d9b/class_autonomous.html#a3dfbbe8cfa9c13c2cb62cf91d93ca32e", null ],
    [ "Init", "de/d9b/class_autonomous.html#a4da7436b4677dd9e54cb11d2b699feb7", null ],
    [ "Loop", "de/d9b/class_autonomous.html#aea97867c75673b2653ab6a0f51865914", null ],
    [ "Stop", "de/d9b/class_autonomous.html#adb96115a31204aecdc9139f910636618", null ],
    [ "m_gyrodrive", "de/d9b/class_autonomous.html#a66186df02dbb95027c5ee93b90cdda24", null ],
    [ "m_heading", "de/d9b/class_autonomous.html#a80890c3af47da0f213644b5090626b7f", null ],
    [ "m_inputs", "de/d9b/class_autonomous.html#a37123be9f545271df90e3a43fb027d7b", null ],
    [ "m_stage", "de/d9b/class_autonomous.html#a6ba9ab444ea06853d393cb82867619b7", null ]
];
var class_dual_gyro =
[
    [ "DualGyro", "d4/d13/class_dual_gyro.html#a1e40c7a8028dd99467c7eb924bc86fc1", null ],
    [ "~DualGyro", "d4/d13/class_dual_gyro.html#a82dfe18d971241f7d5199a883c829994", null ],
    [ "Dashboard", "d4/d13/class_dual_gyro.html#acdf84b764435b91d0138efbf9b3a2cbd", null ],
    [ "GetHeading", "d4/d13/class_dual_gyro.html#a79fb4ec5e97be5c5499070f88cfb7147", null ],
    [ "Init", "d4/d13/class_dual_gyro.html#a5bb5d8e123252f0677baace99afbb5d9", null ],
    [ "Loop", "d4/d13/class_dual_gyro.html#a305ac3b095735450c5401c6ba1b518eb", null ],
    [ "Stop", "d4/d13/class_dual_gyro.html#a267c407962c725818fbee6a2b0c3c089", null ],
    [ "ZeroHeading", "d4/d13/class_dual_gyro.html#af60b637668fe6dc9cfbfa413d6b20ffb", null ],
    [ "m_gyroval1", "d4/d13/class_dual_gyro.html#aa4ed886b0a022ad1130129270eef0ab3", null ],
    [ "m_gyroval2", "d4/d13/class_dual_gyro.html#a943098c8482c4b1517cf9811810bcc59", null ],
    [ "m_gyrovalid1", "d4/d13/class_dual_gyro.html#a600b63febefbbbf382ba3598bbe2ed7a", null ],
    [ "m_gyrovalid2", "d4/d13/class_dual_gyro.html#a6890a3b32598fdc4a089b10eb53dc17f", null ],
    [ "m_heading1", "d4/d13/class_dual_gyro.html#a95da80e5ccc00ef0a2c6d74d59f0cccc", null ],
    [ "m_heading2", "d4/d13/class_dual_gyro.html#a65dee8ee6f6d75a130b837ae483d96fb", null ],
    [ "m_pigeon1", "d4/d13/class_dual_gyro.html#a888e6ce76be51db42004583a9f5123c6", null ],
    [ "m_pigeon2", "d4/d13/class_dual_gyro.html#aede8d2918bea89a464fa0f1bd45f508d", null ]
];